import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Balloon here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Balloon extends Actor
{
    /**
     * Act - do whatever the Balloon wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        checkCollected();
    }
    private void checkCollected() {
        if(isTouching(Person.class)) {
            Person p = (Person) getOneIntersectingObject(Person.class);
            if (p != null) {
                p.giveBalloon();
            }
            getWorld().removeObject(this);
            return;
        }
    }
}
