import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Person here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Person extends Actor
{
    private boolean balloonReady = false;
    /**
     * Act - do whatever the Person wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        handleMovement();
    }
    private void handleMovement() {
        if (Greenfoot.isKeyDown("a")) {
            setLocation(getX() - 4, getY());
        }
        if (Greenfoot.isKeyDown("d")) {
            setLocation(getX() + 4, getY());
        }
    }
    public void giveBalloon() {
        balloonReady = true;
    }
    public void consumeBalloon() {
        balloonReady = false;
    }
    public boolean hasBalloon() {
        return balloonReady;
    }
    
}
