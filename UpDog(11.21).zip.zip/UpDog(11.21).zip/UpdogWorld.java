import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class UpdogWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class UpdogWorld extends World
{
    private int score = 0;
    private int dogSpawnTimer = 0;
    private int balloonSpawnTimer = 0;
    private Person player;
    
    public UpdogWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        prepare();
        showHUD();
    }
    public void act() {
        dogSpawnTimer++;
        
        if (dogSpawnTimer >= 120) {
            spawnDog();
            dogSpawnTimer = 0;
        }
        
        balloonSpawnTimer++;
        if (balloonSpawnTimer >= 90) {
            spawnBalloon();
            balloonSpawnTimer = 0;
        }
        
        showHUD();
    }
        private void prepare() {
        player = new Person();
        addObject(player, getWidth() / 2, getHeight() - 50);
        
        addObject(new Dog(),getWidth() / 2, 0);
        spawnBalloon();
    }
    private void spawnDog() {
        int x = Greenfoot.getRandomNumber(getWidth());
        addObject(new Dog(),x,0);
    }
    private void spawnBalloon() {
        int x = Greenfoot.getRandomNumber(getWidth());
        int y = getHeight() - 30;
        addObject(new Balloon(), x, y);
    }
    public void addScore(int amount) {
        score += amount;
    }
    private void showHUD() {
        showText("Score: " + score, 80, 20);
        
        if (player != null & player.hasBalloon()) {
            showText("Balloon: READY", 110, 40);
        }
        else {
            showText("Balloon: NONE", 110, 40);
        }
    }
    /**
     * Constructor for objects of class UpdogWorld.
     * 
     */
    
}
